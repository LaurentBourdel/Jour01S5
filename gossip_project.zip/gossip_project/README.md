# README

Création des premières pages du projet gossip:

 - La page d'accueil,
 - La page de la team, 
 - La page de contact,
 - La page de bienvenue,
 - La page du potin.
